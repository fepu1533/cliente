<?php
    header("Location: AppLoadingWelcome.php");
?>