

<html style="
    background-color: black;
">
    <head>
	<meta charset="utf-8">
	

	
	<title>admin waler</title>
	
		<style>
		h1 {
					font-family:Georgia, "Times New Roman", Times, serif;
					font-style:italic;
					font-size:30px;
					color:black;
					letter-spacing:-0.05;
					text-shadow:1px 1px 1px red;
		}
		img[src*="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"] {display:none;}
		</style>
		<?php

			include("verifica.php");
			if($_GET["acao"] == logout){
				
				setcookie("logado","");
				echo '
				<script type="text/javascript">
				alert("Voce foi deslogado com sucesso, redirecionando clique em ok");
				location="index.php";
				</script>
				';
			}
		?>

	<body style="
    background-color:red;
"> <p></p>
	<center>
		 <h1 id="test">Sua Infos aqui Walker </h1>
		<center>
		<img src="imagens/lf.gif" width="150px"  style="border-radius: 2000%;">
	</head> </center>
		</a>
		 <br>
		 <br>
	</center>
	<center>

		<style>
		h5,{
					font-family:Georgia, "Times New Roman", Times, serif;
					font-style:italic;
					font-size:30px;
					color:#d9524d;
					letter-spacing:-0.05;
					text-shadow:2px 1px 1px #666;
		}
		body{
		  background: url('imagens/luyz.png') center center no-repeat fixed; 
		  -webkit-background-size: cover;
		  -moz-background-size: cover;
		  -o-background-size: cover;
		  background-size: cover;
		}
		h2 {
					font-family:Georgia, "Times New Roman", Times, serif;
					font-style:italic;
					font-size:30px;
					color:#28a745;
					letter-spacing:-0.05;
					text-shadow:1px 1px 1px 	#000;
		}
	img[src*="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-poweredx
	-by-000webhost-white2.png"] {display:none;}
		</style>
   
	
	</body>
</html>
<font color="green">
